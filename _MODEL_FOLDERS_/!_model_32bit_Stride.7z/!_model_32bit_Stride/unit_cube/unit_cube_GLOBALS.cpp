GLfloat     unit_cube_POSITION[]            =  {  0.0, 0.0, 0.0, 1.0};                                                                   
GLfloat     unit_cube_ROTATE[]              =  {  0.0, 1.0,  0.0, 0.0};                                                                  
GLfloat     unit_cube_SCALE[]               =  {  1.0, 1.0,  1.0, 1.0};                                                                  
//-----------------------------------------------------------------                                                                                   
GLfloat     unit_cube_LIGHT_POSITION_01[]   =  {  2.0, 15.0, 30.0, 1.0};                                                                 
GLfloat     unit_cube_SHININESS             =    80.0;                                                                                   
GLfloat     unit_cube_ATTENUATION           =     1.0;                                                                                   
//-----------------------------------------------------------------                                                                                   
GLuint      unit_cube_VBO;                                                                                                               
GLuint      unit_cube_INDICES_VBO;                                                                                                       
//-----------------------------------------------------------------                                                                                   
GLuint      unit_cube_NORMALMAP;                                                                                                         
GLuint      unit_cube_TEXTUREMAP;                                                                                                        
//====================================================================================   
GLfloat unit_cube_boundingBox[6]; 
